# 나랑 오목 한판

15×15 오목 게임입니다. 당신은 흑돌, 상대는 백돌입니다. 외부 서버 없이 GitHub Pages에서 실행됩니다.

## GitHub Pages 배포
1. 새 GitHub 저장소를 만듭니다.
2. ZIP 안의 `index.html`, `README.md`, `.nojekyll`을 저장소 루트에 업로드합니다.
3. Settings → Pages → Deploy from a branch → `main` / `root`를 선택합니다.
4. 저장 후 생성된 Pages 주소에서 게임을 실행합니다.
